package main

func main(){
// M
// A
}
